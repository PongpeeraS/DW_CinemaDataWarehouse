SELECT distinct(mov.MOV_ID)
, mov.MOV_TITLE
, mov.MOV_LENGTH
, mov.MOV_GENRE
, mov.MOV_SYNOPSIS
, mov.MOV_RELEASE_DATE
, mov.MOV_STUDIO
, mov.MOV_DIRECTOR
, mov.MOV_ACTOR
, mov.MOV_STATUS
FROM  [WH].[dbo].[SHOWTIME] sho, [WH].[dbo].[TICKET] tic, [WH].[dbo].[MOVIE] mov
WHERE sho.MOV_ID = mov.MOV_ID
AND tic.SHO_ID = sho.SHO_ID
