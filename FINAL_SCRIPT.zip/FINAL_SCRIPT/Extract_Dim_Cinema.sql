SELECT distinct(cin.CIN_ID)
, cin.CIN_NUMBER
, cin.CIN_TYPE
, cin.CIN_CAPACITY
, cin.BRA_ID
FROM  [WH].[dbo].[SEAT] sea, [WH].[dbo].[CINEMA] cin
WHERE sea.CIN_ID = cin.CIN_ID
