SELECT distinct(bra.BRA_ID)
, bra.BRA_NAME
, bra.BRA_TYPE
, bra.BRA_REGION
, bra.BRA_LOCATION
FROM  [WH].[dbo].[STAFF] sta, [WH].[dbo].[BRANCH] bra
WHERE sta.BRA_ID = bra.BRA_ID
