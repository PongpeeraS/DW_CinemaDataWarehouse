SELECT dim_time.TIME_ID
,tic.STA_ID
,sta.BRA_ID
,tic.CUS_ID
,pay.PAY_ID
,prm.PRM_ID
,COUNT(ret.RET_ID) as used_amount_receipt
FROM [WH].[dbo].[TICKET] tic
, [WH].[dbo].[RECEIPT] ret
, [SF_DW].[dbo].[Dim_Time] dim_time
, [WH].[dbo].[BRANCH] bra
, [WH].[dbo].[STAFF] sta
, [WH].[dbo].[PAYMENT] pay
, [WH].[dbo].[PROMOTION] prm
, [WH].[dbo].[CUSTOMER] cus
WHERE tic.TIC_DATE = dim_time.TIME_FULLDATE
OR ret.RET_DATE = dim_time.TIME_FULLDATE
AND ret.PAY_ID = pay.PAY_ID
OR tic.PAY_ID = pay.PAY_ID
AND ret.PRM_ID = prm.PRM_ID
OR tic.PRM_ID = prm.PRM_ID
AND ret.STA_ID = sta.STA_ID
OR tic.STA_ID = sta.STA_ID
AND sta.BRA_ID = bra.BRA_ID
GROUP BY dim_time.TIME_ID
,tic.STA_ID
,sta.BRA_ID
,tic.CUS_ID
,pay.PAY_ID
,prm.PRM_ID
