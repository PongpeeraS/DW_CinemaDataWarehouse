SELECT distinct(sta.STA_ID)
, sta.STA_FNAME
, sta.STA_LNAME
, sta.STA_GENDER
, sta.STA_ADDRESS
, sta.STA_EMAIL
, sta.STA_PHONE
, sta.STA_BIRTHDATE
, sta.STA_POSITION
, sta.BRA_ID
FROM  [WH].[dbo].[STAFF] sta, [WH].[dbo].[RECEIPT] ret, [WH].[dbo].[TICKET] tic
WHERE sta.STA_ID = ret.STA_ID
OR sta.STA_ID = tic.STA_ID
