SELECT distinct (cus.CUS_ID)
, cus.CUS_FNAME
, cus.CUS_LNAME
, cus.CUS_GENDER
, cus.CUS_NID
, cus.CUS_EMAIL
, cus.CUS_PHONE
, cus.CUS_BIRTHDATE
, FLOOR(DATEDIFF(day,cus.CUS_BIRTHDATE,GETDATE())/365.25) AS AGE
, cus.CUS_JOB
, cus.CUS_WORKPLACE
, cus.CUS_TYPE
, cus.CUS_LEVEL
, cus.CUS_EXPIRE
FROM [WH].[dbo].[CUSTOMER] cus, [WH].[dbo].[RECEIPT] ret, [WH].[dbo].[TICKET] tic
WHERE cus.CUS_ID = ret.CUS_ID
OR cus.CUS_ID = tic.CUS_ID
