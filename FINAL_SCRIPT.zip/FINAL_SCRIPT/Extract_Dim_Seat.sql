SELECT distinct(sea.SEA_ID)
, sea.SEA_TYPE
, sea.SEA_POSITION
, sea.CIN_ID
FROM [WH].[dbo].[SEAT] sea, [WH].[dbo].[SHOWTIME] sho, [WH].[dbo].[SHOwTIME] sho,
WHERE sho.SEA_ID = sea.SEA_ID
AND tic.SHO_ID = sho.SHO_ID
