DELETE FROM [SF_DW].[dbo].[Fact_Product_Sales];
DELETE FROM [SF_DW].[dbo].[Fact_Ticket_Sales];
DELETE FROM [SF_DW].[dbo].[Fact_Ticket_Transaction];
DELETE FROM [SF_DW].[dbo].[Dim_Time];
DELETE FROM [SF_DW].[dbo].[Dim_Customer];
DELETE FROM [SF_DW].[dbo].[Dim_Branch];
DELETE FROM [SF_DW].[dbo].[Dim_Movie];
DELETE FROM [SF_DW].[dbo].[Dim_Product];
DELETE FROM [SF_DW].[dbo].[Dim_Staff];
DELETE FROM [SF_DW].[dbo].[Dim_Payment];
DELETE FROM [SF_DW].[dbo].[Dim_Promotion];
GO
