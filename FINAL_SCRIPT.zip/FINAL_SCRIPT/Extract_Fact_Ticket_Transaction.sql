SELECT dim_time.TIME_ID
,tic.STA_ID
,sta.BRA_ID
,tic.CUS_ID
,pay.PAY_ID
,prm.PRM_ID
,COUNT(tic.TIC_ID) as used_amount_ticket
FROM [WH].[dbo].[TICKET] tic
, [SF_DW].[dbo].[Dim_Time] dim_time
, [WH].[dbo].[BRANCH] bra
, [WH].[dbo].[STAFF] sta
, [WH].[dbo].[PAYMENT] pay
, [WH].[dbo].[PROMOTION] prm
, [WH].[dbo].[CUSTOMER] cus
WHERE tic.TIC_DATE = dim_time.TIME_FULLDATE
AND tic.PAY_ID = pay.PAY_ID
AND tic.PRM_ID = prm.PRM_ID
AND tic.STA_ID = sta.STA_ID
AND sta.BRA_ID = bra.BRA_ID
AND tic.CUS_ID = cus.CUS_ID
GROUP BY dim_time.TIME_ID
,tic.STA_ID
,sta.BRA_ID
,tic.CUS_ID
,pay.PAY_ID
,prm.PRM_ID
