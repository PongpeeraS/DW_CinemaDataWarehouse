SELECT distinct(pro.PRO_ID)
, pro.PRO_NAME
, pro.PRO_TYPE
, pro.PRO_PRICE
, pro.PRO_AMOUNT
, pro.PRO_UNIT_TYPE
FROM  [WH].[dbo].[RECEIPT_LINE] rel,[WH].[dbo].[PRODUCT] pro
WHERE rel.PRO_ID = pro.PRO_ID
