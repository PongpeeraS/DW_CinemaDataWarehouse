SELECT distinct(pay.PAY_ID)
, pay.PAY_TYPE
, pay.PAY_SERVICE
FROM  [WH].[dbo].[PAYMENT] pay, [WH].[dbo].[RECEIPT] ret, [WH].[dbo].[TICKET] tic
WHERE ret.PAY_ID = pay.PAY_ID
OR tic.PAY_ID = pay.PAY_ID
