SELECT dim_time.TIME_ID
,sta.BRA_ID
,sta.STA_ID
,sho.MOV_ID
,tic.CUS_ID
,COUNT(sho.SHO_ID) as ticket_quantity_sold
,COUNT(sho.SHO_ID)*tic.TIC_PRICE as sale_amount
FROM [WH].[dbo].[TICKET] tic
, [WH].[dbo].[SHOWTIME] sho
, [SF_DW].[dbo].[Dim_Time] dim_time
, [WH].[dbo].[MOVIE] mov
, [WH].[dbo].[BRANCH] bra
, [WH].[dbo].[STAFF] sta
, [WH].[dbo].[SEAT] sea
, [WH].[dbo].[CINEMA] cin
, [WH].[dbo].[CUSTOMER] cus
WHERE tic.TIC_DATE = dim_time.TIME_FULLDATE
AND tic.SHO_ID = sho.SHO_ID
AND sho.MOV_ID = mov.MOV_ID
AND sho.SEA_ID = sea.SEA_ID
AND sea.CIN_ID = cin.CIN_ID
AND cin.BRA_ID = bra.BRA_ID
AND tic.CUS_ID = cus.CUS_ID
AND tic.STA_ID = sta.STA_ID
GROUP BY dim_time.TIME_ID
, sho.SHO_ID
, sta.BRA_ID
, sho.MOV_ID
, tic.CUS_ID
, sta.STA_ID
, tic.TIC_PRICE
