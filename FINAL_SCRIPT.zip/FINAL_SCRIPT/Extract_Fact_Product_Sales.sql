SELECT dim_time.TIME_ID
,rel.PRO_ID
,ret.CUS_ID
,sta.BRA_ID
,ret.STA_ID
,rel.REL_AMOUNT as product_quantity_sold
,rel.REL_AMOUNT*pro.PRO_PRICE as sale_amount
,pro.PRO_PRICE as sale_average
FROM [WH].[dbo].[RECEIPT] ret
, [WH].[dbo].[RECEIPT_LINE] rel
, [SF_DW].[dbo].[Dim_Time] dim_time
, [WH].[dbo].[PRODUCT] pro
, [WH].[dbo].[BRANCH] bra
, [WH].[dbo].[STAFF] sta
WHERE ret.RET_DATE = dim_time.TIME_FULLDATE
AND ret.RET_ID = rel.RET_ID
AND rel.PRO_ID = pro.PRO_ID
AND ret.STA_ID = sta.STA_ID
AND sta.BRA_ID = bra.BRA_ID
