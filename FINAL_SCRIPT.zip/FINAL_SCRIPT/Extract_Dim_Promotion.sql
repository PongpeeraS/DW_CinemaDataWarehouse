SELECT distinct(prm.PRM_ID)
, prm.PRM_NAME
, prm.PRM_USEFOR
, prm.PRM_PARTNER
, prm.PRM_DISCOUNT
FROM  [WH].[dbo].[RECEIPT] ret, [WH].[dbo].[TICKET] tic, [WH].[dbo].[PROMOTION] prm
WHERE ret.PRM_ID = prm.PRM_ID
OR tic.PRM_ID = prm.PRM_ID
